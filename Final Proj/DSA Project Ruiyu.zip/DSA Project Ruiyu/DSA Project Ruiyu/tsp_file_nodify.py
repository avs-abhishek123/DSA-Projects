# -*- coding: utf-8 -*-
"""
Created on Apr 17 2018

@author: Ruiyu Zhang
"""
import os


def is_num(s):
    s=s.replace(' ','')
    s=s.replace('\n','')
    s=s[:3]
    try:
        float(s)
        return True
    except ValueError:
        pass
    try:
        import unicodedata
        unicodedata.numeric(s)
        return True
    except (TypeError, ValueError):
        pass
    return False
def make_non_sci(w):
    #去除科学记数法
    w=str(w)
    if w.find('e+')<0:
        return w
    n=float(w[:-4])*pow(10,int(w[-2:]))
    if float('{:.5f}'.format(n)).is_integer():
        return str(int(n))
    return '{:.5f}'.format(n)
path='C:\\Users\detch\Downloads\ALL_tsp\\'
#detect
tsplist,filelist=[],os.listdir(path)
for file in filelist:
    if file[-3:]=='tsp':
        tsplist.append(file)
        #print('>Detected:',file)

#read and save
for file in tsplist:
    f=open(path+file)
    data=f.read().splitlines()
    for line in data:
        if line[:3]=='DIM' or line[:4]==' DIM':
            dim=int(line[11:])
            break
    if dim is None:
            continue
    if len(data[-3]) > 40:
        print('>Bad file:',file)
        continue
    w=open(path+'done\\'+str(dim)+'.txt','w')
    w.write(str(dim)+'\n')
    for line in data:
        if is_num(line):
            sent=line.split()
            for word in sent:
                w.write(make_non_sci(word)+' ')
            w.write('\n')
    print('>Done:',file)






